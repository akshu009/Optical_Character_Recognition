import pytesseract
from PIL import Image
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
img_file = r"D:\programs\dataset\hello_test.png"
roi_image = "index_roi.png"
img = Image.open(roi_image)
ocr_result = pytesseract.image_to_string(img)
print(ocr_result)
