import pytesseract
from PIL import Image
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
image_file = "D:/programs/dataset/page2/newpaper.png"
img = Image.open(image_file)
ocr_result = pytesseract.image_to_string(img)
print (ocr_result)
