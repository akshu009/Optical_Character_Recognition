import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

dataset_folder = r'D:\programs\dataset\page2'


if not os.path.exists(dataset_folder):
    raise FileNotFoundError(f"The folder '{dataset_folder}' does not exist.")

# Load the dataset
digits = load_digits()

# Extract features (X) and labels (y) from the MNIST dataset
X_mnist, y_mnist = digits.data, digits.target

# Split the MNIST data into training and testing sets
X_mnist_train, X_mnist_test, y_mnist_train, y_mnist_test = train_test_split(X_mnist, y_mnist, test_size=0.2, random_state=42)

# Train a RandomForestClassifier on the MNIST dataset
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_mnist_train, y_mnist_train)

# Predict on the MNIST test set
y_mnist_pred = clf.predict(X_mnist_test)

# Evaluate the performance on the MNIST test set
accuracy_mnist = accuracy_score(y_mnist_test, y_mnist_pred)
print(f"Accuracy on MNIST test set: {accuracy_mnist:.2%}")


X_page2, y_page2 = digits.data, digits.target

# Predict on the 'page2' dataset
y_page2_pred = clf.predict(X_page2)

# Evaluate the performance on the 'page2' dataset
accuracy_page2 = accuracy_score(y_page2, y_page2_pred)
print(f"Accuracy on 'self_line' dataset: {accuracy_page2:.2%}")
accuracies = [accuracy_mnist, accuracy_page2]

# Dataset labels
datasets = ['MNIST', 'page2']

# Plotting the bar graph
plt.figure(figsize=(8, 6))
plt.bar(datasets, accuracies, color=['yellow', 'green'])
plt.title('Accuracy of RandomForestClassifier')
plt.xlabel('Dataset')
plt.ylabel('Accuracy')
plt.ylim(0, 1)  # Set y-axis limit to 0-100%
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()